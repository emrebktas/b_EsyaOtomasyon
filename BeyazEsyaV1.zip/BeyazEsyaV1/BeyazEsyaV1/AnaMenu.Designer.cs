﻿namespace BeyazEsyaV1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            panel1 = new Panel();
            panel4 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel2 = new Panel();
            panel3 = new Panel();
            panel11 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            button1 = new Button();
            panel8 = new Panel();
            panel9 = new Panel();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            pictureBox5 = new PictureBox();
            panel10 = new Panel();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(781, 86);
            panel1.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(0, 64, 64);
            panel4.Location = new Point(0, 69);
            panel4.Name = "panel4";
            panel4.Size = new Size(877, 20);
            panel4.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 89);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 20F);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(148, 9);
            label1.Name = "label1";
            label1.Size = new Size(531, 46);
            label1.TabIndex = 0;
            label1.Text = "Beyaz Eşya Otomasyon Sistemi";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Teal;
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 86);
            panel2.Name = "panel2";
            panel2.Size = new Size(122, 338);
            panel2.TabIndex = 3;
            panel2.Paint += panel2_Paint;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Teal;
            panel3.Controls.Add(panel11);
            panel3.Controls.Add(panel5);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 424);
            panel3.Name = "panel3";
            panel3.Size = new Size(781, 50);
            panel3.TabIndex = 4;
            // 
            // panel11
            // 
            panel11.BackColor = Color.White;
            panel11.Location = new Point(702, 18);
            panel11.Name = "panel11";
            panel11.Size = new Size(175, 32);
            panel11.TabIndex = 0;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(0, 64, 64);
            panel5.Location = new Point(-122, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(999, 20);
            panel5.TabIndex = 6;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(0, 64, 64);
            panel6.Location = new Point(122, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(20, 474);
            panel6.TabIndex = 7;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(0, 64, 64);
            panel7.Location = new Point(682, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(20, 474);
            panel7.TabIndex = 8;
            // 
            // button1
            // 
            button1.BackColor = Color.LemonChiffon;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI Black", 13F);
            button1.ForeColor = Color.FromArgb(0, 64, 64);
            button1.Location = new Point(141, 86);
            button1.Name = "button1";
            button1.Size = new Size(276, 176);
            button1.TabIndex = 9;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(0, 64, 64);
            panel8.Location = new Point(141, 251);
            panel8.Name = "panel8";
            panel8.Size = new Size(558, 14);
            panel8.TabIndex = 6;
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(0, 64, 64);
            panel9.Location = new Point(406, 86);
            panel9.Name = "panel9";
            panel9.Size = new Size(14, 338);
            panel9.TabIndex = 9;
            // 
            // button2
            // 
            button2.BackColor = Color.LemonChiffon;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI Black", 13F);
            button2.ForeColor = Color.FromArgb(0, 64, 64);
            button2.Location = new Point(420, 86);
            button2.Name = "button2";
            button2.Size = new Size(276, 176);
            button2.TabIndex = 10;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.LemonChiffon;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI Black", 13F);
            button3.ForeColor = Color.FromArgb(0, 64, 64);
            button3.Location = new Point(141, 265);
            button3.Name = "button3";
            button3.Size = new Size(276, 176);
            button3.TabIndex = 11;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.LemonChiffon;
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Segoe UI Black", 13F);
            button4.ForeColor = Color.FromArgb(0, 64, 64);
            button4.Location = new Point(420, 265);
            button4.Name = "button4";
            button4.Size = new Size(276, 176);
            button4.TabIndex = 12;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.LemonChiffon;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(531, 160);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(51, 31);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.LemonChiffon;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(522, 337);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(60, 31);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.LemonChiffon;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(239, 160);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(70, 31);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.LemonChiffon;
            label2.Font = new Font("Segoe UI Black", 14F);
            label2.ForeColor = Color.FromArgb(0, 64, 0);
            label2.Location = new Point(223, 125);
            label2.Name = "label2";
            label2.Size = new Size(100, 32);
            label2.TabIndex = 16;
            label2.Text = "Satışlar";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.LemonChiffon;
            label3.Font = new Font("Segoe UI Black", 14F);
            label3.ForeColor = Color.FromArgb(0, 64, 0);
            label3.Location = new Point(506, 125);
            label3.Name = "label3";
            label3.Size = new Size(105, 32);
            label3.TabIndex = 17;
            label3.Text = "Müşteri";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.LemonChiffon;
            label4.Font = new Font("Segoe UI Black", 14F);
            label4.ForeColor = Color.FromArgb(0, 64, 0);
            label4.Location = new Point(211, 302);
            label4.Name = "label4";
            label4.Size = new Size(126, 32);
            label4.TabIndex = 18;
            label4.Text = "Çalışanlar";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.LemonChiffon;
            label5.Font = new Font("Segoe UI Black", 14F);
            label5.ForeColor = Color.FromArgb(0, 64, 0);
            label5.Location = new Point(506, 302);
            label5.Name = "label5";
            label5.Size = new Size(102, 32);
            label5.TabIndex = 19;
            label5.Text = "Ürünler";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.LemonChiffon;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(239, 337);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(70, 31);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 20;
            pictureBox5.TabStop = false;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Teal;
            panel10.Location = new Point(702, 86);
            panel10.Name = "panel10";
            panel10.Size = new Size(79, 338);
            panel10.TabIndex = 21;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(781, 474);
            Controls.Add(panel10);
            Controls.Add(pictureBox5);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(panel9);
            Controls.Add(panel8);
            Controls.Add(panel7);
            Controls.Add(button1);
            Controls.Add(panel2);
            Controls.Add(panel6);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(button2);
            Controls.Add(button3);
            Controls.Add(button4);
            Name = "Form2";
            Text = "Ana Menü";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Button button1;
        private Panel panel8;
        private Panel panel9;
        private Button button2;
        private Button button3;
        private Button button4;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox5;
        private Panel panel11;
        private Panel panel10;
    }
}