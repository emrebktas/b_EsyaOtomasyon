﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;

namespace BeyazEsyaV1
{

    public partial class Calisanlar : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=beyazesyadb;Uid=root;Pwd=sjhdbx61qwe."); //databasele ilişki kurma
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt;

        void calisanlarr()
        {
            dt = new DataTable();
            con.Open();
            adapter = new MySqlDataAdapter("SELECT *FROM calisanlar", con);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            con.Close();
        }
        public Calisanlar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO calisanlar(CalisanID, Ad, Soyad, Pozisyon, Maas, BaslamaTarihi)" + "VALUES(@CalisanID, @Ad, @Soyad, @Pozisyon, @Maas, @BaslamaTarihi)";
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("CalisanID", textBox1.Text);
            cmd.Parameters.AddWithValue("Ad", textBox2.Text);
            cmd.Parameters.AddWithValue("Soyad", textBox3.Text);
            cmd.Parameters.AddWithValue("Pozisyon", textBox4.Text);
            cmd.Parameters.AddWithValue("Maas", textBox5.Text);
            cmd.Parameters.AddWithValue("BaslamaTarihi", textBox6.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            calisanlarr();
            MessageBox.Show("Çalışan başarıyla eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = ("DELETE FROM calisanlar WHERE CalisanID = @CalisanID");
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("CalisanID", textBox1.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            calisanlarr();
            MessageBox.Show("Çalışan başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            calisanlarr();
        }
    }
}
