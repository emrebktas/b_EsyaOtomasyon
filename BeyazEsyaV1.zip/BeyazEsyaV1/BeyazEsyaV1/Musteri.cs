﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;

namespace BeyazEsyaV1
{
    public partial class Musteri : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=beyazesyadb;Uid=root;Pwd=sjhdbx61qwe."); //databasele ilişki kurma
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt;

        void musterii()
        {
            dt = new DataTable();
            con.Open();
            adapter = new MySqlDataAdapter("SELECT *FROM musteriler", con);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            con.Close();
        }
        public Musteri()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO musteriler(MusteriID, Ad, Soyad, Telefon, Adres)" + "VALUES(@MusteriID, @Ad, @Soyad, @Telefon, @Adres)";
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("MusteriID", textBox1.Text);
            cmd.Parameters.AddWithValue("Ad", textBox2.Text);
            cmd.Parameters.AddWithValue("Soyad", textBox3.Text);
            cmd.Parameters.AddWithValue("Telefon", textBox4.Text);
            cmd.Parameters.AddWithValue("Adres", textBox5.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            musterii();
            MessageBox.Show("Kayıt başarıyla eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = ("DELETE FROM musteriler WHERE MusteriID = @MusteriID");
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("MusteriID", textBox1.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            musterii();
            MessageBox.Show("Kayıt başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            musterii();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
