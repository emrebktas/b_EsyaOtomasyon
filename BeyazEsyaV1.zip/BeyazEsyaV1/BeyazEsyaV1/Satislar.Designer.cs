﻿namespace BeyazEsyaV1
{
    partial class Satislar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Satislar));
            panel6 = new Panel();
            panel2 = new Panel();
            panel10 = new Panel();
            panel7 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel4 = new Panel();
            panel1 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            panel3 = new Panel();
            panel5 = new Panel();
            textBox6 = new TextBox();
            button3 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            button1 = new Button();
            textBox7 = new TextBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(0, 64, 64);
            panel6.Location = new Point(119, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(20, 364);
            panel6.TabIndex = 26;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Teal;
            panel2.Controls.Add(panel6);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 86);
            panel2.Name = "panel2";
            panel2.Size = new Size(140, 364);
            panel2.TabIndex = 23;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Teal;
            panel10.Location = new Point(898, 181);
            panel10.Name = "panel10";
            panel10.Size = new Size(175, 338);
            panel10.TabIndex = 41;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(0, 64, 64);
            panel7.Location = new Point(878, 95);
            panel7.Name = "panel7";
            panel7.Size = new Size(20, 474);
            panel7.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 20F);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(148, 9);
            label1.Name = "label1";
            label1.Size = new Size(531, 46);
            label1.TabIndex = 0;
            label1.Text = "Beyaz Eşya Otomasyon Sistemi";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, -9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(125, 89);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(0, 64, 64);
            panel4.Location = new Point(0, 69);
            panel4.Name = "panel4";
            panel4.Size = new Size(877, 20);
            panel4.TabIndex = 5;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Teal;
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 86);
            panel1.TabIndex = 22;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(0, 64, 64);
            panel8.Location = new Point(707, 3);
            panel8.Name = "panel8";
            panel8.Size = new Size(20, 447);
            panel8.TabIndex = 6;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Teal;
            panel9.Location = new Point(722, 86);
            panel9.Name = "panel9";
            panel9.Size = new Size(82, 314);
            panel9.TabIndex = 42;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(0, 64, 64);
            panel3.Location = new Point(0, 395);
            panel3.Name = "panel3";
            panel3.Size = new Size(800, 20);
            panel3.TabIndex = 6;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Teal;
            panel5.Location = new Point(136, 414);
            panel5.Name = "panel5";
            panel5.Size = new Size(573, 36);
            panel5.TabIndex = 43;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Segoe UI", 9F);
            textBox6.Location = new Point(159, 260);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(104, 27);
            textBox6.TabIndex = 78;
            textBox6.Text = "Miktar";
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(255, 255, 128);
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(587, 310);
            button3.Name = "button3";
            button3.Size = new Size(104, 79);
            button3.TabIndex = 77;
            button3.Text = "Satışları Listele";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 128, 128);
            button2.Cursor = Cursors.Hand;
            button2.Location = new Point(477, 310);
            button2.Name = "button2";
            button2.Size = new Size(104, 79);
            button2.TabIndex = 70;
            button2.Text = "Satış Sil";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(282, 95);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RightToLeft = RightToLeft.No;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(419, 201);
            dataGridView1.TabIndex = 76;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 9F);
            textBox5.Location = new Point(159, 227);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(104, 27);
            textBox5.TabIndex = 75;
            textBox5.Text = "SatisTarihi";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 9F);
            textBox4.Location = new Point(159, 194);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(104, 27);
            textBox4.TabIndex = 74;
            textBox4.Text = "CalisanID";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 9F);
            textBox3.Location = new Point(159, 161);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(104, 27);
            textBox3.TabIndex = 73;
            textBox3.Text = "MusteriID";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 9F);
            textBox2.Location = new Point(159, 128);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(104, 27);
            textBox2.TabIndex = 72;
            textBox2.Text = "UrunID";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 9F);
            textBox1.Location = new Point(159, 95);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(104, 27);
            textBox1.TabIndex = 71;
            textBox1.Text = "SatisID";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 255, 128);
            button1.Cursor = Cursors.Hand;
            button1.Location = new Point(367, 310);
            button1.Name = "button1";
            button1.Size = new Size(104, 79);
            button1.TabIndex = 69;
            button1.Text = "Satış Ekle";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Segoe UI", 9F);
            textBox7.Location = new Point(159, 293);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(104, 27);
            textBox7.TabIndex = 79;
            textBox7.Text = "ToplamFiyat";
            // 
            // Satislar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(dataGridView1);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Controls.Add(panel8);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel9);
            Controls.Add(panel10);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(panel7);
            Name = "Satislar";
            Text = "Satislar";
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel6;
        private Panel panel2;
        private Panel panel10;
        private Panel panel7;
        private Label label1;
        private PictureBox pictureBox1;
        private Panel panel4;
        private Panel panel1;
        private Panel panel8;
        private Panel panel9;
        private Panel panel3;
        private Panel panel5;
        private TextBox textBox6;
        private Button button3;
        private Button button2;
        private DataGridView dataGridView1;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button1;
        private TextBox textBox7;
    }
}