﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;

namespace BeyazEsyaV1
{
    public partial class Satislar : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=beyazesyadb;Uid=root;Pwd=sjhdbx61qwe."); //databasele ilişki kurma
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt;

        void satislarr()
        {
            dt = new DataTable();
            con.Open();
            adapter = new MySqlDataAdapter("SELECT *FROM satislar", con);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            con.Close();
        }
        public Satislar()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string sql = "INSERT INTO satislar(SatisID, UrunID, MusteriID, CalisanID, SatisTarihi, Miktar, ToplamFiyat)" + "VALUES(@SatisID, @UrunID, @MusteriID, @CalisanID, @SatisTarihi, @Miktar, @ToplamFiyat)";
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("SatisID", textBox1.Text);
            cmd.Parameters.AddWithValue("UrunID", textBox2.Text);
            cmd.Parameters.AddWithValue("MusteriID", textBox3.Text);
            cmd.Parameters.AddWithValue("CalisanID", textBox4.Text);
            cmd.Parameters.AddWithValue("SatisTarihi", textBox5.Text);
            cmd.Parameters.AddWithValue("Miktar", textBox6.Text);
            cmd.Parameters.AddWithValue("ToplamFiyat", textBox7.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            satislarr();
            MessageBox.Show("Satış başarıyla eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = ("DELETE FROM satislar WHERE SatisID = @SatisID");
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("SatisID", textBox1.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            satislarr();
            MessageBox.Show("Satış başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            satislarr();
        }
    }
}
