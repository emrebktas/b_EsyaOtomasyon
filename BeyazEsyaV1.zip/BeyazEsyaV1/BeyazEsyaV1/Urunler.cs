﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BeyazEsyaV1
{
    public partial class Urunler : Form
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=beyazesyadb;Uid=root;Pwd=sjhdbx61qwe."); //databasele ilişki kurma
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        DataTable dt;

        void urunlerr()
        {
            dt = new DataTable();
            con.Open();
            adapter = new MySqlDataAdapter("SELECT *FROM urunler", con);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            con.Close();
        }
        public Urunler()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO urunler(UrunID, UrunAdi, Fiyat, StokMiktari, MarkaID)" + "VALUES(@UrunID, @UrunAdi, @Fiyat, @StokMiktari, @MarkaID)";
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("UrunID", textBox1.Text);
            cmd.Parameters.AddWithValue("UrunAdi", textBox2.Text);
            cmd.Parameters.AddWithValue("Fiyat", textBox3.Text);
            cmd.Parameters.AddWithValue("StokMiktari", textBox4.Text);
            cmd.Parameters.AddWithValue("MarkaID", textBox5.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            urunlerr();
            MessageBox.Show("Ürün başarıyla eklendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            urunlerr();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sql = ("DELETE FROM urunler WHERE UrunID = @UrunID");
            cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("UrunID", textBox1.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            urunlerr();
            MessageBox.Show("Ürün başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        

        private void button4_Click(object sender, EventArgs e)
        {
            dt = new DataTable();
            con.Open();
            adapter = new MySqlDataAdapter("SELECT * FROM UrunDetaylari", con);
            dataGridView1.DataSource = dt;
            adapter.Fill(dt);
            con.Close();
        }
    }
}
